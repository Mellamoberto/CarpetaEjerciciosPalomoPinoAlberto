package tiendaPC;

import java.sql.*;

public class BorrarDatos {

	public static void main(String[] args) throws SQLException{
		// TODO Auto-generated method stub
		Connection conn= null;
		Statement stmt = null;

	}

}
